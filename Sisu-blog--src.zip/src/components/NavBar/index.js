import React from "react";
import styled from "styled-components";
import { motion } from "framer-motion";
import { Button } from "@shopify/polaris";

const Holder = styled(motion.div)`
  transition: all 300ms ease-in-out;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  position: fixed;
  top: 0;
  right: 0;
  left: 0;
  z-index: 9;
  background: ${({ active }) => (active ? "#fff" : "transparent")}; /* ${({
    theme,
  }) => theme.primaryBackground}; */
  border-bottom: ${({ active }) =>
    active ? "1px solid #dfe3e9" : "transparent"}; /* ; */
  height: 60px;
`;
// const Button = styled.h1`
//   font-size: 1.5em;
//   text-align: center;
//   color: palevioletred;
// `;
const Logo = styled.img`
  ${({ theme }) => theme.logo.style};
  filter: ${({ active }) => (active ? "brightness(1)" : "brightness(10)")};
`;

const Menu = styled.div`
  display: flex;
  align-items: center;
  padding-right: 20px;
  > a {
    color: ${({ active }) => (active ? "#333" : "#000")};
    font-weight: ${({ active }) => (active ? "300" : "800")};
  }
  > span {
    color: ${({ active, theme }) => (active ? theme.accentColor : "#000")};
  }
`;

const MenuItem = styled.a`
  color: #000;
  font-weight: 300;
  font-size: 17px;
  margin-right: 18px;
  padding: 10px;
  text-decoration: none;
  ${({ active }) => active && "font-weight: 800 !important"};
`;
const FancyHeader = ({ theme, scrollY, onLoginClick }) => {
  return (
    <Holder>
      <h1>Sisu.</h1>
      <Menu>
        <MenuItem href="#Features">Features</MenuItem>
        <MenuItem href="#HowItWorks">How It Works</MenuItem>
        <MenuItem href="#Pricing">Pricing</MenuItem>
        <span>
          <Button onClick={onLoginClick} outline monochrome>
            Login/Signup
          </Button>
        </span>
      </Menu>
    </Holder>
  );
};

export default FancyHeader;
