import React from "react";
import styled from "styled-components";
import { motion } from "framer-motion";
import { Button, ButtonGroup } from "@shopify/polaris";
import logo from "../../sisu-blog-image-1.png";

import ImagePlaceholder from "../../sisu-blog-image-1.png";
import Purple from "../../purple.png";

const breakPoints = {
  xs: "@media (max-width: 374.98px)",
  s: "@media (max-width: 767.98px)",
  m: "@media (max-width: 959.98px)",
  l: "@media (max-width: 1199.98px)",
};

const Link = styled.a``;

const Container = styled.div`
  width: 800px;
  max-width: 90%;
  margin: 200px auto;
`;

const MainArticle = styled.div`
  width: 100%;

  margin: 0 auto;
  display: flex;
  justify-content: center;
  align-items: center;
  margin-bottom: 40px;
  border-radius: 15px;
  transition: 1s;
  flex-direction: column;
`;

const ContentTag = styled.a`
  color: #8d8bd4;
  padding: 10px 15px;
  background: #e3e3f7;
  border-radius: 50px;
  font-weight: 600;
`;

const DateTag = styled.a`
  color: #8d8bd4;
  padding: 10px 15px;
  background: none;
  border-radius: 50px;
  font-weight: 400;
`;

const Heading = styled.div`
  color: #575757;
  margin: 30px 0px 10px 0px;
  font-size: 30px;
  line-height: 1.3;
`;

const Excerpt = styled.div`
  color: #9f9eb3;
  font-size: 14px;
  line-height: 1.5;
  margin: 10px 0;
`;

const ArticleImage = styled.div`
  margin: 20px;
`;

const Content = styled.div`
  color: #9f9eb3;
  font-size: 14px;
  line-height: 1.5;
  margin: 10px 30px;
`;

const Share = styled.div`
  color: #9f9eb3;
  font-size: 14px;
  line-height: 1.5;
  margin: 10px 30px;
  display: flex;
  width: 100%;
`;

const BlogPost = ({ onLoginClick }) => {
  // const history = useHistory()
  return (
    <div>
      <Container>
        <div>
          <Link to="/lorem-ipsum-dolor-sit-amet-consectetur">
            <MainArticle>
              <div
                style={{
                  margin: "0px 50px ",
                }}
              >
                <ContentTag>NEWS</ContentTag>
                <DateTag> 9 September 2020</DateTag>
                <Heading>SISU hits 5000 Apps within 6 months</Heading>
                <Excerpt>
                  Scenester wayfarers narwhal deep v hot chicken irony. Pop-up
                  vexillologist cred, poke pok pok direct trade.
                </Excerpt>
              </div>
              <ArticleImage>
                <img
                  src={ImagePlaceholder}
                  alt="Purple"
                  style={{
                    maxWidth: "100%",
                  }}
                />
              </ArticleImage>

              <Content>
                <p>
                  Ut enim ad minim veniam, quis nostrud exercitation ullamco
                  laboris nisi ut aliquip ex ea commodo consequat. Duis aute
                  irure dolor in reprehenderit in voluptate velit esse cillum
                  dolore eu fugiat nulla pariatur. Excepteur sint occaecat
                  cupidatat non proident, sunt in culpa qui officia deserunt
                  mollit anim id est laborum. Ut enim ad minim veniam, quis
                  nostrud exercitation ullamco laboris nisi ut aliquip ex ea
                  commodo consequat. Ut enim ad minim veniam, quis nostrud
                  exercitation ullamco laboris nisi ut aliquip ex ea commodo
                  consequat. Duis aute irure dolor in reprehenderit in voluptate
                  velit esse cillum dolore eu fugiat nulla pariatur. Excepteur
                  sint occaecat cupidatat non proident, sunt in culpa qui
                  officia deserunt mollit anim id est laborum. Ut enim ad minim
                  veniam, quis nostrud exercitation ullamco laboris nisi ut
                  aliquip ex ea commodo consequat. Ut enim ad minim veniam, quis
                  nostrud exercitation ullamco laboris nisi ut aliquip ex ea
                  commodo consequat. Duis aute irure dolor in reprehenderit in
                  voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                  Excepteur sint occaecat cupidatat non proident, sunt in culpa
                  qui officia deserunt mollit anim id est laborum. Ut enim ad
                  minim veniam, quis nostrud exercitation ullamco laboris nisi
                  ut aliquip ex ea commodo consequat.
                </p>
                <div style={{ display: "flex", width: "100%" }}>
                  <img
                    src={Purple}
                    alt="Purple"
                    style={{
                      maxWidth: "100%",
                      margin: "30px",
                    }}
                  />
                </div>
                <p>
                  Ut enim ad minim veniam, quis nostrud exercitation ullamco
                  laboris nisi ut aliquip ex ea commodo consequat. Duis aute
                  irure dolor in reprehenderit in voluptate velit esse cillum
                  dolore eu fugiat nulla pariatur. Excepteur sint occaecat
                  cupidatat non proident, sunt in culpa qui officia deserunt
                  mollit anim id est laborum. Ut enim ad minim veniam, quis
                  nostrud exercitation ullamco laboris nisi ut aliquip ex ea
                  commodo consequat. Ut enim ad minim veniam, quis nostrud
                  exercitation ullamco laboris nisi ut aliquip ex ea commodo
                  consequat. Duis aute irure dolor in reprehenderit in voluptate
                  velit esse cillum dolore eu fugiat nulla pariatur. Excepteur
                  sint occaecat cupidatat non proident, sunt in culpa qui
                  officia deserunt mollit anim id est laborum. Ut enim ad minim
                  veniam, quis nostrud exercitation ullamco laboris nisi ut
                  aliquip ex ea commodo consequat. Ut enim ad minim veniam, quis
                  nostrud exercitation ullamco laboris nisi ut aliquip ex ea
                  commodo consequat. Duis aute irure dolor in reprehenderit in
                  voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                  Excepteur sint occaecat cupidatat non proident, sunt in culpa
                  qui officia deserunt mollit anim id est laborum. Ut enim ad
                  minim veniam, quis nostrud exercitation ullamco laboris nisi
                  ut aliquip ex ea commodo consequat.
                </p>
                <div style={{ display: "flex" }}>
                  <img
                    src={Purple}
                    alt="Purple"
                    style={{
                      maxWidth: "100%",
                      margin: "30px",
                    }}
                  />
                </div>
              </Content>
            </MainArticle>
          </Link>
        </div>
      </Container>
    </div>
  );
};

export default BlogPost;
