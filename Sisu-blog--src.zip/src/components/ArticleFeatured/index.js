import React from "react";
import styled from "styled-components";
import { motion } from "framer-motion";
import { Button, ButtonGroup } from "@shopify/polaris";
import logo from "../../sisu-blog-image-1.png";

const breakPoints = {
  xs: "@media (max-width: 374.98px)",
  s: "@media (max-width: 767.98px)",
  m: "@media (max-width: 959.98px)",
  l: "@media (max-width: 1199.98px)",
};

const Link = styled.a``;

const Container = styled.div`
  max-width: 1140px;
  margin: 100px auto;
`;

const MainArticle = styled.div`
  width: 100%;

  margin: 0 auto;
  display: flex;
  justify-content: center;
  align-items: center;
  margin-bottom: 40px;
  border-radius: 15px;
  transition: 1s;
  ${breakPoints.m} {
    flex-wrap: wrap;
  }
`;

const MainImage = styled.div`
  margin: 0 50px;
  max-width: 80%;
`;

const MainBody = styled.div`
  max-width: 80%;
  margin-right: 50px;
  ${breakPoints.m} {
    margin-top: 50px;
    margin-right: 0px;
  }
`;

const ContentTag = styled.a`
  color: #8d8bd4;
  padding: 10px 15px;
  background: #e3e3f7;
  border-radius: 50px;
  font-weight: 600;
`;

const Heading = styled.div`
  color: #575757;
  margin: 30px 0px 10px 0px;
  font-size: 30px;
  line-height: 1.3;
`;

const Content = styled.div`
  color: #9f9eb3;
  font-size: 14px;
  line-height: 1.5;
  margin: 10px 0;
`;

const ReadMore = styled.a`
  color: #9f9eb3;
  font-size: 12px;
  line-height: 1.5;
  padding-top: 20px;
  padding-bottom: 5px;
  border-bottom: 1px solid #9f9eb3;
  cursor: pointer;
`;

const ArticleFeatured = ({ onLoginClick }) => {
  // const history = useHistory()
  return (
    <div>
      <Container>
        <div>
          <Link to="/lorem-ipsum-dolor-sit-amet-consectetur">
            <MainArticle>
              <MainImage>
                <img
                  src={logo}
                  alt="Logo"
                  style={{
                    width: "100%",
                  }}
                />
              </MainImage>
              <MainBody>
                <ContentTag>NEWS</ContentTag>
                <Heading>SISU hits 5000 Apps within 6 months</Heading>
                <Content>
                  Scenester wayfarers narwhal deep v hot chicken irony. Pop-up
                  vexillologist cred, poke pok pok direct trade.
                </Content>
                <ReadMore to="/href">Read More</ReadMore>
              </MainBody>
            </MainArticle>
          </Link>
        </div>
      </Container>
    </div>
  );
};

export default ArticleFeatured;
