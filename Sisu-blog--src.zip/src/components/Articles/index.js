import React from "react";
import styled from "styled-components";
import { motion } from "framer-motion";
import { Button, ButtonGroup } from "@shopify/polaris";
import logo from "../../sisu-blog-image-1.png";
import Yellow from "../../yellow.png";
import Orange from "../../orange.png";
import Green from "../../green.png";
import Blue from "../../blue.png";
import Pink from "../../pink.png";
import Purple from "../../purple.png";

const breakPoints = {
  xs: "@media (max-width: 374.98px)",
  s: "@media (max-width: 767.98px)",
  m: "@media (max-width: 959.98px)",
  l: "@media (max-width: 1199.98px)",
};

const Container = styled.div`
  max-width: 1140px;
  margin: 100px auto;
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
`;

const MainArticle = styled.div`
  max-width: 28%;
  float: left;
  transition: 0.5s;
  background: #fff;
  border-radius: 25px;
  padding: 20px;
  cursor: pointer;
  margin: 20px;
  :hover {
    box-shadow: 2px 3px 14px 0px rgba(225, 225, 240, 0.5);
  }
  ${breakPoints.m} {
    max-width: 40%;
  }
  ${breakPoints.s} {
    max-width: 80%;
  }
  ${breakPoints.xs} {
    max-width: 80%;
  }
`;

const MainImage = styled.div`
  margin: 0px;
`;

const Heading = styled.div`
  color: #575757;
  margin: 20px 0px 10px 0px;
  font-size: 16px;
  line-height: 1.3;
`;

const Excerpt = styled.div`
  color: #9f9eb3;
  font-size: 12px;
  line-height: 1.5;
  margin: 10px 0;
`;

const ReadMore = styled.a`
  color: #9f9eb3;
  font-size: 12px;
  line-height: 1.5;
  padding-top: 20px;
  padding-bottom: 5px;
  border-bottom: 1px solid #9f9eb3;
`;

const ContentTagGuide = styled.a`
  color: #fed187;
  padding: 10px 15px;
  background: #fff5e5;
  border-radius: 15px;
  font-weight: 600;
`;

const ContentTagTrend = styled.a`
  color: #ffaa95;
  padding: 10px 15px;
  background: #ffe5df;
  border-radius: 15px;
  font-weight: 600;
`;
const ContentTagGrow = styled.a`
  color: #a0dac5;
  padding: 10px 15px;
  background: #e2f3ed;
  border-radius: 15px;
  font-weight: 600;
`;

const ContentTag = styled.a`
  color: #e2f3ed;
  padding: 10px 15px;
  background: #e3e3f7;
  border-radius: 15px;
  font-weight: 600;
`;
const Article = ({ onLoginClick }) => {
  // const history = useHistory()
  return (
    <div>
      <Container>
        <MainArticle>
          <MainImage>
            <img
              src={Yellow}
              alt="Yellow"
              style={{
                width: "100%",
              }}
            />
          </MainImage>
          <div style={{ padding: "20px" }}>
            <ContentTagGuide>GUIDE</ContentTagGuide>
            <Heading>Amazing base theme or customise it fully</Heading>
            <Excerpt>
              Scenester wayfarers narwhal deep v hot chicken irony. Pop-up
              vexillologist cred, poke pok pok direct trade.
            </Excerpt>
            <ReadMore to="/href">Read More</ReadMore>
          </div>
        </MainArticle>
        <MainArticle>
          <MainImage>
            <img
              src={Orange}
              alt="Orange"
              style={{
                width: "100%",
              }}
            />
          </MainImage>
          <div style={{ padding: "20px" }}>
            <ContentTagTrend>TRENDS</ContentTagTrend>
            <Heading>Amazing base theme or customise it fully</Heading>
            <Excerpt>
              Scenester wayfarers narwhal deep v hot chicken irony. Pop-up
              vexillologist cred, poke pok pok direct trade.
            </Excerpt>
            <ReadMore to="/href">Read More</ReadMore>
          </div>
        </MainArticle>
        <MainArticle>
          <MainImage>
            <img
              src={Green}
              alt="Green"
              style={{
                width: "100%",
              }}
            />
          </MainImage>
          <div style={{ padding: "20px" }}>
            <ContentTagGrow>GROW</ContentTagGrow>
            <Heading>Amazing base theme or customise it fully</Heading>
            <Excerpt>
              Scenester wayfarers narwhal deep v hot chicken irony. Pop-up
              vexillologist cred, poke pok pok direct trade.
            </Excerpt>
            <ReadMore to="/href">Read More</ReadMore>
          </div>
        </MainArticle>

        <MainArticle>
          <MainImage>
            <img
              src={Blue}
              alt="Blue"
              style={{
                width: "100%",
              }}
            />
          </MainImage>
          <div style={{ padding: "20px" }}>
            <ContentTag>TRENDS</ContentTag>
            <Heading>Amazing base theme or customise it fully</Heading>
            <Excerpt>
              Scenester wayfarers narwhal deep v hot chicken irony. Pop-up
              vexillologist cred, poke pok pok direct trade.
            </Excerpt>
            <ReadMore to="/href">Read More</ReadMore>
          </div>
        </MainArticle>
        <MainArticle>
          <MainImage>
            <img
              src={Pink}
              alt="Pink"
              style={{
                width: "100%",
              }}
            />
          </MainImage>
          <div style={{ padding: "20px" }}>
            <ContentTag>NEWS</ContentTag>
            <Heading>Amazing base theme or customise it fully</Heading>
            <Excerpt>
              Scenester wayfarers narwhal deep v hot chicken irony. Pop-up
              vexillologist cred, poke pok pok direct trade.
            </Excerpt>
            <ReadMore to="/href">Read More</ReadMore>
          </div>
        </MainArticle>
        <MainArticle>
          <MainImage>
            <img
              src={Purple}
              alt="Purple"
              style={{
                width: "100%",
              }}
            />
          </MainImage>
          <div style={{ padding: "20px" }}>
            <ContentTag>NEWS</ContentTag>
            <Heading>Amazing base theme or customise it fully</Heading>
            <Excerpt>
              Scenester wayfarers narwhal deep v hot chicken irony. Pop-up
              vexillologist cred, poke pok pok direct trade.
            </Excerpt>
            <ReadMore to="/href">Read More</ReadMore>
          </div>
        </MainArticle>
      </Container>
    </div>
  );
};

export default Article;
