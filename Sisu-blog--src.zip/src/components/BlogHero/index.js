import React from "react";
import styled from "styled-components";
import { motion } from "framer-motion";
import { Button, ButtonGroup } from "@shopify/polaris";

const breakPoints = {
  xs: "@media (max-width: 374.98px)",
  s: "@media (max-width: 767.98px)",
  m: "@media (max-width: 959.98px)",
  l: "@media (max-width: 1199.98px)",
};

const MasterPageHolder = styled.div`
  max-width: 1400px;
  margin-left: auto;
  margin-right: auto;
  display: flex;
  flex-wrap: wrap;
  flex: 1;
`;

const Container = styled.div`
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  padding: 0px 40px;
`;

const InfoContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  min-width: 250px;
  max-width: 500px;
  margin-bottom: 30px;
`;
const InfoTitle = styled.h1`
  font-size: 30px;
  line-height: 1.1em;
  margin-bottom: 14px;
  font-weight: 400;
  color: #8c8ccf;
  letter-spacing: 2px;
  text-align: center;
`;

const BlogHero = ({ onLoginClick }) => {
  // const history = useHistory()
  return (
    <div
      style={{
        display: "flex",
        position: "relative",
        width: "100%",
        alignItems: "center",
        paddingTop: "150px",
      }}
    >
      <MasterPageHolder>
        <Container>
          <InfoContainer>
            <InfoTitle>RESOURCES & UPDATES</InfoTitle>
            <div
              style={{
                marginBottom: "36px",
                width: "100%",
                color: "#757592",

                textAlign: "center",
              }}
            >
              Everything you need to build your Sisu App
            </div>
            <input
              style={{
                margin: "15px auto",
                width: "70%",
                background: "#f8f8fc",
                borderRadius: "10px",
                padding: "15px 15px",
                border: "none",
              }}
              placeholder="Search"
              className="form-control"
            />

            <div
              style={{
                color: "#757592",
                justifyContent: "center",
                display: "flex",
                width: "100%",
              }}
            ></div>
          </InfoContainer>
        </Container>
      </MasterPageHolder>
    </div>
  );
};

export default BlogHero;
