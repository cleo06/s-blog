import React from "react";
import { AppProvider } from "@shopify/polaris";
import enTranslations from "@shopify/polaris/locales/en.json";

// import logo from "./logo.svg";
import "./App.css";
import NavBar from "./components/NavBar/index";
import BlogHero from "./components/BlogHero/index";
import ArticleFeatured from "./components/ArticleFeatured/index";
import Articles from "./components/Articles/index";
import BlogPost from "./components/BlogPost/index";

function App() {
  return (
    <AppProvider i18n={enTranslations}>
      <NavBar />

      <BlogHero />
      <ArticleFeatured />
      <Articles />
      {/* 
      <BlogPost /> */}
    </AppProvider>
  );
}

export default App;
